#ifndef __BITLBEE_CHECK_H__
#define __BITLBEE_CHECK_H__ 

#include "irc.h"

irc_t *torture_irc(void);
gboolean g_io_channel_pair(GIOChannel **ch1, GIOChannel **ch2);

#endif /* __BITLBEE_CHECK_H__ */
